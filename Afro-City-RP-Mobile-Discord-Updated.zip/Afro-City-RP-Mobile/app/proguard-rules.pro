-keep class com.nvidia.devtech.* { *; }
-keep class com.rockstargames.gtasa.* { *; }
-keep class com.wardrumstudios.utils.* { *; }

-keep class com.afrocityrp.game.* { *; }
-keep class com.afrocityrp.game.ui.* { *; }
-keep class com.afrocityrp.game.ui.widgets.* { *; }
-keep class com.afrocityrp.game.ui.widgets.adapter.* { *; }

-keep class com.afrocityrp.launcher.utils.SignatureChecker { *; }

# for minify
-dontwarn javax.servlet.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**