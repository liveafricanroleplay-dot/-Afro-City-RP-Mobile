Put these files in jniLibs/armeabi-v7a/ before building (all from a legitimate copy of GTA:SA 2.10 / mod tools):

  libGTASA.so          GTA:SA 2.10 (Rockstar) - required
  libImmEmulatorJ.so   from the same GTA:SA APK - required on 32-bit
  libBASS.so           audio (Un4seen) - needed for voice/audio
  libCLEO.so           optional, CLEO scripts
  libAML.so            optional, AML mod loader
  libmonetloader.so    optional, MonetLoader Lua scripts

libAfroCityRP.so is built from the C++ source by Gradle, do not add it here.
Game data goes on the phone in Android/data/com.afrocityrp.launcher/files/
